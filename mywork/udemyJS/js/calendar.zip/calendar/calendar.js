const CURRENT_YEAR   = new Date().getFullYear();
const CURRENT_MONTH  = new Date().getMonth() + 1;
const CURRENT_DATE   = new Date().getDate();
const DAY_OF_WEEK      = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const MONTH_HEADER_NAME= ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const getYear  = document.getElementById('setYear');
const getMonth = document.getElementById('setMonth');
const prevMonth= document.getElementById('prevMonth');
const nextMonth= document.getElementById('nextMonth');
const areaUserSetDate = document.getElementById('areaUserSetDate');

const moveNextMonth = () => {
    if (Number(getMonth.value) === 12) {
        getYear.value++;
        getMonth.value = 1;
    } else {
        getMonth.value++;
    }
    generateCalenderTable(getYear.value, getMonth.value);
};

const movePreviousMonth = () => {
    if (Number(getMonth.value) === 1) {
        getYear.value--;
        getMonth.value = 12;
    } else {
        getMonth.value--;
    }
    generateCalenderTable(getYear.value, getMonth.value);
}

const checkErrorDate = (year, month) => {

    let errYearCaption = document.getElementById('captionYear');
    let errMonthCaption= document.getElementById('captionMonth');

    let yearRange     = (1900 <= year) && (year <= 2100) ? 'in' : 'out';
    let monthRange    = (1 <= month) && (month <= 12) ? 'in' : 'out';

    let errMessage    = "* 눈을 들어 BOX를 보라";
    let errCssOutline = "2px solid #f06e50";

    const setError = (e1_Message1, e2_Message2, e1_Outline1, e2_Outline2) => {
        errYearCaption.innerText  = e1_Message1;
        errMonthCaption.innerText = e2_Message2;
        getYear.style.outline  = e1_Outline1;
        getMonth.style.outline = e2_Outline2;
    };

    if (yearRange === 'in' && monthRange === 'in') {
        setError("", "", "0", "0");
        generateCalenderTable(year, month)
    } else if (yearRange === 'out' && monthRange === 'out') {
        setError(errMessage, errMessage, errCssOutline, errCssOutline);
    } else if (yearRange === 'in' && monthRange === 'out') {
        setError("", errMessage, "0", errCssOutline);
    } else {
        setError(errMessage, "", errCssOutline, "0");
    }
}


const setHerder = (month) => {
    let header = document.getElementById('header');

    header.innerText = MONTH_HEADER_NAME[month - 1].toUpperCase();
}

const setDayOfWeek = () => {
    const thead = document.querySelector('thead');
    let outputCalendar= '';

    Array.from(DAY_OF_WEEK).forEach(day => outputCalendar += `<th>${day}</th>`);
    thead.innerHTML = outputCalendar;
}

const generateCalenderTable = (year, month) => {

    const lastDate  = new Date(year, month, 0).getDate();
    const firstDate = new Date(year, month - 1, 1);
    const tbody = document.querySelector('tbody');
    const maxIndex = lastDate + (6 - new Date(year, month - 1, lastDate).getDay()) + firstDate.getDay();

    let date= 1;
    let isPossibleDateInput= false;
    let outputCalendar= '';

    setHerder(month);

    for (let col = 1; col <= maxIndex; col++) {

        let createTd = `<td class="containDate row${col % 7}">${date}</td>`;
        let createTodayTd = `<td class="containDate row${col % 7} today"><div class="todayCaption">today</div>${date}</td>`;

        let checkToday =
            Number(date)  === Number(CURRENT_DATE)  &&
            Number(month) === Number(CURRENT_MONTH) &&
            Number(year)  === Number(CURRENT_YEAR)   ? 'y' : 'n';

        if (col % 7 === 1) {
            outputCalendar += '<tr>';
        }

        if (isPossibleDateInput) {
                if (checkToday === 'y') {
                    outputCalendar += createTodayTd;
                } else {
                    outputCalendar += createTd;
                }
                date++;
        } else if (Math.floor((col - 1) / 7) === 0 && firstDate.getDay() === (col - 1) % 7) {
                if (checkToday === 'y') {
                    outputCalendar += createTodayTd;
                } else {
                    outputCalendar += createTd;
                }
                date++;
                isPossibleDateInput = !isPossibleDateInput;
        } else {
            outputCalendar += '<td></td>';
        }

        if (date - 1 === lastDate) {
            date = 0;
            isPossibleDateInput = !isPossibleDateInput;
        }

        if (col % 7 === 0) {
            outputCalendar += '</tr>';
        }
    }
    tbody.innerHTML = outputCalendar;
}


window.addEventListener('load', function () {

    setDayOfWeek();

    getYear.value  = CURRENT_YEAR;
    getMonth.value = CURRENT_MONTH;

    generateCalenderTable(getYear.value, getMonth.value);

    areaUserSetDate.addEventListener('change', () => checkErrorDate(getYear.value, getMonth.value));

    prevMonth.addEventListener('click', movePreviousMonth);
    nextMonth.addEventListener('click', moveNextMonth);

});
